<?php include '../php/control.php'; ?><!DOCTYPE html>
<html>
  <head>
    <title>Travel Modes in Directions</title>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 85%;
      }

      /* Optional: Makes the sample page fill the window. */
      html,
      body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
      img{
        margin: 0;
        padding: 0;
        padding-left: 1% !important;
        padding-top: 3% !important;
      }

    </style>
    <script>
      var empLatitude = <?php echo selectAllData($conn,'location','Latitude','custID',selectAllData($conn,'employee','empID','empEmail',$_SESSION['emailEmp'])); ?>;
      var empLogitude = <?php echo selectAllData($conn,'location','Longitude','custID',selectAllData($conn,'employee','empID','empEmail',$_SESSION['emailEmp'])); ?>;

      var userLatitude = <?php echo selectAllData($conn,'location','Latitude','custID',$_GET['useIdMap']); ?>;
      var userLogitude = <?php echo selectAllData($conn,'location','Longitude','custID',$_GET['useIdMap']); ?>;

      function initMap() {
        const directionsRenderer = new google.maps.DirectionsRenderer();
        const directionsService = new google.maps.DirectionsService();
        const map = new google.maps.Map(document.getElementById("map"), {
          zoom: 10,
          center: { lat: empLatitude, lng: empLogitude },
        });
        directionsRenderer.setMap(map);
        calculateAndDisplayRoute(directionsService, directionsRenderer);
        document.getElementById("mode").addEventListener("change", () => {
          calculateAndDisplayRoute(directionsService, directionsRenderer);
        });
      }

      function calculateAndDisplayRoute(directionsService, directionsRenderer) {
        const selectedMode = document.getElementById("mode").value;
        directionsService
          .route({
            origin: { lat: empLatitude, lng: empLogitude},
            destination: { lat: userLatitude, lng: userLogitude },
            // Note that Javascript allows us to access the constant
            // using square brackets and a string value as its
            // "property."
            travelMode: google.maps.TravelMode[selectedMode],
          })
          .then((response) => {
            directionsRenderer.setDirections(response);
          })
          .catch((e) => window.alert("Directions request failed due to " + status));
      }
    </script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  </head>
  <body style="background-color: purple;">
    <div class="container">
      <div class="row" style="padding: 1%;">
        <div class="col">
        <div class="logo"><a href="dashboard.php" class="simple-text logo-normal" style="text-decoration: none; color: white;">
      <img src="./assets/img/hair-cutting (1).png" width="50" alt=""><span style="padding-top: 50px !important;"> Home</span>
      </a>
    </div>
        </div>
        <div class="col">
          <div id="floating-panel" style="padding-top: 3%;">
            <b class="text-white">Mode of Travel: </b>
            <select id="mode">
              <option value="DRIVING">Driving</option>
            </select>
          </div>
        </div>

      </div>
    </div>

    <div id="map"></div>
    

    <!-- Async script executes immediately and must be after any DOM elements used in callback. -->
    <script
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDNNpZLzHIO3x8w-z36vTTCG-Fqa4v5dRE&callback=initMap&libraries=&v=weekly"
      async
    ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>