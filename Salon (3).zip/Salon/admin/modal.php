    <!-- Modal Users-->
    <div class="modal fade" id="usersModal" tabindex="-1" aria-labelledby="usersModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="usersModalLabel">Modal title</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="content">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-md-12">
                    <div class="card">
                      <div class="card-header card-header-primary">
                        <h4 class="card-title "><i class="fas fa-users"></i> Registered users</h4>
                        
                      </div>
                      <a style="padding-left: 5%; padding-top: 2%;" href="../php/user-report.php"><i class="far fa-file-pdf"></i> Download As PDF</a>
                      <div class="card-body">
                        <div class="table-responsive">
                          <table class="table">
                            <thead class=" text-primary">
                              <th>
                                ID
                              </th>
                              <th>
                                Name
                              </th>
                              <th>
                                Surname
                              </th>
                              <th>
                                Oders
                              </th>
                              <th>
                                Record
                              </th>
                            </thead>
                            <tbody>
                              <?php while($row = $resultSelectAllcustomers->fetch_assoc()): ?>
                                <tr>
                                <td>
                                  <?php echo $row['custID']; ?>
                                </td>
                                <td>
                                  <?php echo $row['custName']; ?>
                                </td>
                                <td>
                                  <?php echo $row['custSurname']; ?>
                                </td>
                                <td>
                                  <?php  
                                    if($row['AppointmentID'] != 0 ){
                                        echo 'Active';
                                    }else{
                                      echo 'None';
                                    }
                                  ?>
                                </td>
                                <td class="text-primary">
                                  <a href="user-record.php?userId=<?php echo $row['custID']; ?>">Open</a>
                                </td>
                              </tr>
                              <?php endwhile; ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>

    <!-- Modal Oders-->
    <div class="modal fade" id="odersModal" tabindex="-1" aria-labelledby="usersModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="usersModalLabel"><img src="./assets/img/hair-cutting (1).png" width="40" alt=""> Active oders</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="content">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-md-12">
                    <div class="card">
                      <div class="card-header card-header-primary">
                        <h4 class="card-title "><i class="fas fa-clipboard-list"></i> Total number of oders</h4>
                      </div>
                      <a style="padding-left: 5%; padding-top: 2%;" href="../php/oder-report.php"><i class="far fa-file-pdf"></i> Download As PDF</a>

                      <div class="card-body">
                        <div class="table-responsive">
                          <table class="table">
                            <thead class=" text-primary">
                              <th>
                                ID
                              </th>
                              <th>
                                Name
                              </th>
                              <th>
                                Style
                              </th>
                              <th class="text-center">
                                Payment Satus
                              </th>
                              <th>
                                Oder Record
                              </th>
                            </thead>
                            <tbody>
                              <?php while ($row = $resultSelectAllOders->fetch_assoc()): ?>
                                <tr>
                                  <td>
                                    <?php echo $row['appointmentID']; ?>
                                  </td>
                                  <td>
                                    <?php echo selectAllData($conn,'customers','custName','custID',$row['custID']); ?>
                                  </td>
                                  <td>
                                    <?php echo selectAllData($conn,'hairstyle','hairStyleName','hairStyleID', selectAllData($conn,'appointment','hairStyleID','custID',$row['custID'])); ?>
                                  </td>
                                  <td class="text-success text-center">
                                    R <?php echo selectAllData($conn,'payment','amoutRand','custID',$row['custID']); ?>
                                  </td>
                                  <td class="text-primary">
                                  <a href="oder-record.php?recordId=<?php echo  selectAllData($conn,'customers','custID','custID',$row['custID']); ?>">Open</a>
                                  </td>
                                </tr>
                              <?php endwhile; ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal emoloyees-->
    <div class="modal fade" id="empModal" tabindex="-1" aria-labelledby="usersModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="usersModalLabel">Active Oders</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="content">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-md-12">
                    <div class="card">
                      <div class="card-header card-header-primary">
                        <div class="container">
                          <div class="row">
                            <div class="col-8">
                              <h4 class="card-title "><i class="material-icons">library_books</i> Employees records</h4>
                            </div>
                            <div class="col-4"><button class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#empModalAdd">Add New Employee</button></div>
                          </div>
                        </div>
                      </div>
                      <a style="padding-left: 5%; padding-top: 2%;" href="../php/emp-report.php"><i class="far fa-file-pdf"></i> Download As PDF</a>

                      <div class="card-body">
                        <div class="table-responsive">
                          <table class="table">
                            <thead class=" text-primary">
                              <th>
                                ID
                              </th>
                              <th>
                                Name
                              </th>
                              <th>
                                Surname
                              </th>
                              <th>
                                Apointment
                              </th>
                              <th>
                                Email
                              </th>
                              <th>
                                Record
                              </th>
                            </thead>
                            <tbody>
                              <?php while ($row = $resultSelectAllemployee->fetch_assoc()): ?>
                                <tr>
                                  <td>
                                    <?php echo $row['empID']; ?>
                                  </td>
                                  <td>
                                    <?php echo $row['empName']; ?>
                                  </td>
                                  <td>
                                    <?php echo $row['empSurname']; ?>
                                  </td>
                                  <td>
                                    <?php  
                                      if($row['appointmentID'] == 0){
                                        echo 'Open';
                                      }else{
                                        echo 'Has a client';
                                      }
                                    ?>
                                  </td>
                                  <td>
                                    <?php echo $row['empEmail']; ?>
                                  </td>
                                  <td class="text-primary">
                                    <a href="employee-record.php?recordId=<?php echo $row['empID']; ?>">Open</a>
                                  </td>
                                </tr>
                              <?php endwhile; ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Modal emoloyees ADD-->
    <div class="modal fade" id="empModalAdd" tabindex="-1" aria-labelledby="usersModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="usersModalLabel">ADD</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="content">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-md-12">
                    <div class="card">
                      <div class="card-header card-header-primary">
                        <div class="container">
                          <div class="row">
                            <div class="col-8">
                              <h4 class="card-title "><i class="material-icons">library_books</i> Employees records</h4>
                            </div>
                            
                          </div>
                        </div>
                      </div>
                      <div class="card-body">
                        <div class="row">
                          <div class="col-sm-6">
                            <div>
                              <div class="card-body">
                                <form method="POST">
                                    <div class="mb-3">
                                      <input type="email" class="form-control" oninput="ValidateEmail('email');" id="email" name="email" placeholder="name@example.com" required>
                                    </div>
                                    <div class="mb-3">
                                      <input type="password" class="form-control" oninput="CheckPassword('password');" id="password" name="password" placeholder="Password" required>
                                    </div>
                                    <div class="mb-3">
                                      <input type="text" class="form-control" oninput="validationText('name');" id="name" name="name" placeholder="Name" required>
                                    </div>
                                    <div class="mb-3">
                                      <input type="text" class="form-control" oninput="validationText('surname');" id="surname" name="surname" placeholder="Surname" required>
                                    </div>
                                    <button type="submit" name="btnAddEmp" id="btnBtn" class="btn btn-primary" style="width:100%; border-radius: 20px;">Add New Employee</button>
                                </form>
                              </div>
                            </div>
                          </div>
                          <div class="col-sm-6">
                              <div class="card-body text-center">
                                <br>
                                <i class="fas fa-user-plus fa-9x text-primary"></i>
                              </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Employee loction-->
    <div class="modal fade" id="locationActivation" tabindex="-1" aria-labelledby="usersModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="usersModalLabel">Location setup</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="content">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-md-12">
                    <div class="card">

                      <div class="card-body">
                        <div class="row text-center">
                          <i class="fas fa-map-marker-alt text-primary fa-9x"></i>
                          <div class="card-body text-center">
                              <img src="./assets/img/location.png" width="300" alt="">
                              <div class="text-center" style="padding-top: 3px !important;">
                              <h2 class="text-dark"></h2>
                              <div id="result">
                                  <!--Position information will be inserted here-->
                              </div>
                              <button onclick="showPosition();" type="button" class="btn bg-primary" style="border-radius: 20px;">Enable Location</button>
                              </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal admin-->
    <div class="modal fade" id="adminModal" tabindex="-1" aria-labelledby="usersModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="usersModalLabel">Admin</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="content">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-md-12">
                    <div class="card">
                      <div class="card-header card-header-primary">
                        <h4 class="card-title "><i class="fas fa-user-cog"></i> Admin section</h4>
                      </div>
                      <div class="card-body">
                          <div class="row">
                            <div class="col-sm-6">
                              <div class="card-body text-center">
                                <br>
                                  <i class="fas fa-user-cog fa-9x text-success"></i>
                                  <br>
                              </div>
                            </div>
                            <div class="col-sm-6">
                              <div class="card" style="border-radius: 20px;">
                                <div class="card-body text-center">
                                  <ul class="list-group list-group-flush">
                                    <i class="fas fa-user-lock fa-2x text-danger"></i>
                                    <li class="list-group-item"><?php echo selectAllData($conn,'admin','email','email',$_SESSION['emailAdmin']); ?></li>
                                  </ul>
                                  <a data-bs-toggle="modal" data-bs-target="#adminModalUpdate" class="btn btn-primary text-white" style="border-radius: 20px;">updated admin info</a>
                                </div>
                              </div>
                            </div>
                          </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Modal admin update-->
    <div class="modal fade" id="adminModalUpdate" tabindex="-1" aria-labelledby="usersModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="usersModalLabel">Admin</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="content">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-md-12">
                    <div class="card">
                      <div class="card-header card-header-primary">
                        <h4 class="card-title "><i class="fas fa-user-cog"></i> Admin section</h4>
                      </div>
                      <div class="card-body">
                          <div class="row">
                            <div class="col-sm-6">
                              <div class="card-body text-center">
                                <br>
                                <form method="POST">
                                    <div class="mb-3">
                                      <input type="email" class="form-control" name="email" placeholder="name@example.com" required value="<?php echo selectAllData($conn,'admin','email','email',$_SESSION['emailAdmin']); ?>">
                                    </div>
                                    <div class="mb-3">
                                      <input type="password" class="form-control" name="password" placeholder="Password" required value="<?php echo selectAllData($conn,'admin','password','email',$_SESSION['emailAdmin']); ?>">
                                    </div>
                                    <button type="submit" name="btnUpdateAdmin" class="btn btn-primary" style="width:100%; border-radius: 20px;">Update</button>
                                </form>
                              </div>
                            </div>
                            <div class="col-sm-6">
                              <div class="card" style="border-radius: 20px;">
                                <div class="card-body text-center">
                                  <ul class="list-group list-group-flush">
                                    <i class="fas fa-user-lock fa-8x text-danger"></i>
                                    <li class="list-group-item"><?php echo selectAllData($conn,'admin','email','email',$_SESSION['emailAdmin']); ?></li>
                                  </ul>
                                </div>
                              </div>
                            </div>
                          </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal admin update-->
    <div class="modal fade" id="updateProfileEmp" tabindex="-1" aria-labelledby="usersModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="usersModalLabel">Admin</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="content">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-md-12">
                    <div class="card">
                      <div class="card-header card-header-primary">
                        <h4 class="card-title "><i class="fas fa-user-cog"></i> Admin section</h4>
                      </div>
                      <div class="card-body">
                          <div class="row">
                            <div class="col-sm-6">
                              <div class="card-body text-center">
                                <br>
                                <form method="POST">
                                    <div class="mb-3">
                                      <input type="email" class="form-control" name="email" value="<?php echo selectAllData($conn,'employee','empEmail','empEmail',$_SESSION['emailEmp']); ?>" placeholder="name@example.com" required>
                                    </div>
                                    <div class="mb-3">
                                      <input type="password" class="form-control" name="password" value="<?php echo selectAllData($conn,'employee','empPassword','empEmail',$_SESSION['emailEmp']); ?>" placeholder="Password" required>
                                    </div>
                                    <div class="mb-3">
                                      <input type="text" class="form-control" name="name" value="<?php echo selectAllData($conn,'employee','empName','empEmail',$_SESSION['emailEmp']); ?>"  placeholder="Name" required>
                                    </div>
                                    <div class="mb-3">
                                      <input type="text" class="form-control" name="surname" value="<?php echo selectAllData($conn,'employee','empSurname','empEmail',$_SESSION['emailEmp']); ?>"  placeholder="Surname" required>
                                    </div>
                                    <button type="submit" name="btnUpdatEmp" class="btn btn-primary" style="width:100%; border-radius: 20px;">Update info</button>
                                </form>
                              </div>
                            </div>
                            <div class="col-sm-6">
                              <div class="card" style="border-radius: 20px;">
                                <div class="card-body text-center">
                                  <ul class="list-group list-group-flush">
                                    <i class="fas fa-user-edit fa-8x"></i>
                                  </ul>
                                </div>
                              </div>
                            </div>
                          </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
