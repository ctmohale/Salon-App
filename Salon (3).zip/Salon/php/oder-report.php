<?php
include './connect.php';
include './control.php';
require('./fpdf/fpdf.php');

class PDF extends FPDF
{
    function hader()
    {
        $this->SetFont('Arial', 'B', 14);
        $this->Cell(276, 5, 'Salon ( Control Management System ) ', 0, 0, 'C');
        $this->Ln();
        $this->SetFont('Times', '', 12);
        $this->Cell(276, 10, 'Order records', 0, 0, 'C');
        $this->Ln(20);
        $this->Cell(276, 10, '--------------------------------------------------------------------', 0, 0, 'C');
        $this->Ln(20);
    }
    function footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial', '', 8);
        //$this->Cell(0, 10, 'Page'.this->PageNo().'/{nb}',0,0, 'C');
    }
    function headerTable()
    {
        $this->SetFont('Times', 'B', 12);
        $this->Cell(10, 10, 'Id', 1, 0, 'C');
        $this->Cell(70, 10, 'Name', 1, 0, 'C');
        $this->Cell(40, 10, 'Surname', 1, 0, 'C');
        $this->Cell(30, 10, 'Payment', 1, 0, 'C');
        $this->Cell(30, 10, 'Date', 1, 0, 'C');
        $this->Cell(30, 10, 'Time', 1, 0, 'C');
        $this->Cell(30, 10, 'Hair Style', 1, 0, 'C');
        $this->Cell(30, 10, 'Service Type', 1, 0, 'C');
        $this->Ln();
    }
    function dataFromDb($conn)
    {
        $this->SetFont('Times', '', 12);
        $sql = "SELECT*From appointment";
        $result = $conn->query($sql);

        while ($row = $result->fetch_assoc()) {
            $this->SetFont('Times', 'B', 12);
            $this->Cell(10, 10, $row['appointmentID'], 1, 0, 'L');
            $this->Cell(70, 10, selectAllData($conn,'customers','custName','custID',$row['custID']), 1, 0, 'L');
            $this->Cell(40, 10, selectAllData($conn,'customers','custSurname','custID',$row['custID']), 1, 0, 'L');
            $this->Cell(30, 10, selectAllData($conn,'payment','amoutRand','custID',$row['custID']), 1, 0, 'L');
            $this->Cell(30, 10, $row['appointDate'], 1, 0, 'L');
            $this->Cell(30, 10, $row['appointTime'], 1, 0, 'L');
            $this->Cell(30, 10, selectAllData($conn,'hairstyle','hairStyleName','hairStyleID',$row['hairStyleID']), 1, 0, 'L');
            $this->Cell(30, 10, $row['service_location'], 1, 0, 'L');
            $this->Ln();
        }
    }
}
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage('L', 'A4', 0);
$pdf->hader();
$pdf->headerTable();
$pdf->dataFromDb($conn);
$pdf->Output();
