<?php
    //All variables should be here
    //__________________________________________________________________________________________
    //Main conrol var
    $sessionOff = "none";
    $mainUserPage = "none";

    //User Variables
    $userUpdateError = "none";
    $userSuccess = "none";
    $userSuccessPointmentAlert = "none";

    //Register variables
    $registerSccess = "none";
    $registerFail = "none";
    $userExist = "none";

    //Price For hair styles
    $styleA = 150;
    $styleB = 300;
    $styleC = 200;
    $styleD = 180;
    $styleE = 300;

    //Booking control
    $globalBookingControl = "makeABooking";
    $globalAccessBooking = "accessBookings";

    //Cancel oder
    $alertCancellSuccess = "none";

    //Main admin variables
    $mainSectionAdmin = "none";
    $sessionOver = "none";

    $showAdmin = "none";

    //Admin $alertCancellSuccess
    $adminUpdateSuccess = "none";
    $adminAddEmp = "none";
    $adminAddEmpExist = "none";
    $alertAdminDeleteSucces = "none";
    $adminUpdateEmp = "none";

    $alertOderComplete = "none";
    
    //Distance calculation and const
    $distanceKillo = 0;
    $homeCalTotalPrice = 0;

    //Checing if employee as set the location
    $locationEmpSet = "none";
    $hideOders = "none";

    $successEmpProfile = "none";
    $hideProfileOnAdmin = "none";

    $deleteUserAdmin = "none";
    $adminL = "";

    $alertWrongP = "none";
    $alertWrongE = "none";