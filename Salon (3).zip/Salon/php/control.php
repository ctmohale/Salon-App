<?php
@session_start();

//_________________________________________________________________
//Link to all the external sscript
include 'connect.php';
include 'sqlFunctions.php';
include 'variable.php';
//__________________________________________________________________
//Login section
//Check if the email exist first
if(isset($_POST['btnLogin'])){

    if(selectAllData($conn,'customers','custEmail','custEmail',$_POST['email']) == $_POST['email']){

        //Check if the password exist
        if(selectAllData($conn,'customers','custPassword','custPassword',$_POST['password']) == $_POST['password']){

            //set all session to be active
            $_SESSION['email'] = $_POST['email'];
    
            //Direct admin to the dashbord
            header('Location:./user.php');
        }
        else{
            //Direct to the login page with password error 
            header('Location:index.php?password=error');
            //exit();
        }
    
    }else{
        header('Location:index.php?email=error');
        //exit();

    }
}
if(isset($_GET['password'])){
    if($_GET['password']){
        echo "Wrong password";
        exit();
    }
}
if(isset($_GET['email'])){
    if($_GET['email']){
        echo "Wrong email";
        exit();
    }
}
//__________________________________________________________________
//Logged in to system
if(isset($_SESSION['email'])){
    //Update user information
    $sessionOff = "none";
    $mainUserPage = "";
    if(isset($_POST['btnUpdateUserInfo'])){

        updateFunction($conn,'customers','custName',$_POST['name'],'custEmail',$_SESSION['email']);
        updateFunction($conn,'customers','custSurname',$_POST['surname'],'custEmail',$_SESSION['email']);
        updateFunction($conn,'customers','custID_NO',$_POST['id_No'],'custEmail',$_SESSION['email']);
        updateFunction($conn,'customers','custEmail',$_POST['email'],'custEmail',$_SESSION['email']);
        updateFunction($conn,'customers','custPassword',$_POST['password'],'custEmail',$_SESSION['email']);
        updateFunction($conn,'customers','custContact',$_POST['cell_no'],'custEmail',$_SESSION['email']);

        if(isset($_POST['id_No'])){
            $Gender = "";
            //Get Gender from an id number 
            if(intval(substr($_POST['id_No'],6,1)) < 5){ $Gender = "Female";} else{ $Gender = "Male"; }
            updateFunction($conn,'customers','Gender',$Gender,'custEmail',$_SESSION['email']);
        }  
        $userSuccess = "";

    }
    //Complete Booking

    if(isset($_GET['style'])){
        
        if($_GET['style'] == 'Mohawk'){
            $_SESSION['style'] = selectAllData($conn,'hairstyle','hairStyleName','hairStyleName','Mohawk');;
            $_SESSION['Price'] = selectAllData($conn,'hairstyle','hairStylePrice','hairStyleName','Mohawk');
            $_SESSION['stleId'] = selectAllData($conn,'hairstyle','hairStyleID','hairStyleName','Mohawk');

        }else if($_GET['style'] == 'StraightBack'){
            $_SESSION['style'] = selectAllData($conn,'hairstyle','hairStyleName','hairStyleName','Straight back');;
            $_SESSION['Price'] = selectAllData($conn,'hairstyle','hairStylePrice','hairStyleName','Straight back');
            $_SESSION['stleId'] = selectAllData($conn,'hairstyle','hairStyleID','hairStyleName','Straight back');

           

        }
        else if($_GET['style'] == 'StraightUp'){
            $_SESSION['style'] = selectAllData($conn,'hairstyle','hairStyleName','hairStyleName','Straight up');;
            $_SESSION['Price'] = selectAllData($conn,'hairstyle','hairStylePrice','hairStyleName','Straight up');
            $_SESSION['stleId'] = selectAllData($conn,'hairstyle','hairStyleID','hairStyleName','Straight up');

        }
        else if($_GET['style'] == 'Wig'){
            $_SESSION['style'] = selectAllData($conn,'hairstyle','hairStyleName','hairStyleName','Wig');;
            $_SESSION['Price'] = selectAllData($conn,'hairstyle','hairStylePrice','hairStyleName','Wig');
            $_SESSION['stleId'] = selectAllData($conn,'hairstyle','hairStyleID','hairStyleName','Wig');
        }
    }
    if(isset($_POST['proceedToPayMent'])){
                
        $_SESSION['ServiceLocation'] = $_POST['serviceLocation'];
        $_SESSION['Date'] = $_POST['date'];
        $_SESSION['Time'] = $_POST['time'];
        $_SESSION['empId'] = $_POST['empId'];

        if($_SESSION['ServiceLocation'] != 'Salon'){

            header('Location:location.php');
        }
    }

    //Home salon
    if(isset($_GET['lattitude']) && isset($_GET['Longitude'])){

        $_SESSION['lattt'] = $_GET['lattitude'];
        $_SESSION['Logg'] = $_GET['Longitude'];
        
        $distanceKillo = distanceA($_SESSION['lattt'],$_SESSION['Logg'], floatval(selectAllData($conn,'location','Latitude','custID',$_SESSION['empId'])),floatval(selectAllData($conn,'location','Longitude','custID',$_SESSION['empId'])));
        $_SESSION['distanceKillo'] = $distanceKillo;
        $totalC = $_SESSION['Price'] + $distanceKillo*selectAllData($conn,'ratesperkilometre','rate','Id',1);
        $_SESSION['Price'] = $totalC;
     
        header('Location:calculatingCost.php?processCost=true');
    }

    if(isset($_POST['proceedToPayMentWithLocation'])){
        header('Location:complete-oder.php?completePayment=true');
    }
    if(isset($_GET['completePayment'])){
        if(isset($_GET['completePayment']) == true){
            $_SESSION['ServiceLocationWithMainLocation'] = true;
        }
    }
    ///////////////////////////////////////////////////////////////////////

    if(isset($_SESSION['ServiceLocationWithMainLocation'])){
        if($_SESSION['ServiceLocationWithMainLocation'] == true){
            //Check if transaction is complete
            if(isset($_GET['transection'])){
                if($_GET['transection'] == 'confirmation'){
                    insertAppointemt($conn,$_SESSION['Date'],$_SESSION['Time'],selectAllData($conn,'customers','custID','custEmail',$_SESSION['email']),$_SESSION['empId'],$_SESSION['ServiceLocation'], $_SESSION['stleId']);
                    insertHairstyle($conn,$_SESSION['style'],selectAllData($conn,'customers','custID','custEmail',$_SESSION['email']));
                    insertPayment($conn,selectAllData($conn,'customers','custID','custEmail',$_SESSION['email']),$_SESSION['empId'],$_SESSION['Price'],selectAllData($conn,'hairstyle','hairStyleID','hairStyleName',$_SESSION['style']));

                    if(selectAllData($conn,'location','custID','custID',selectAllData($conn,'customers','custID','custEmail',$_SESSION['email'])) == true){
                        updateFunction($conn,'employee','Latitude',$_SESSION['lattt'],'custID',selectAllData($conn,'customers','custID','custEmail',$_SESSION['email']));
                        updateFunction($conn,'employee','Longitude',$_SESSION['Logg'],'custID',selectAllData($conn,'customers','custID','custEmail',$_SESSION['email']));
                    }else{
                        insertLocation($conn,selectAllData($conn,'customers','custID','custEmail',$_SESSION['email']),$_SESSION['lattt'],$_SESSION['Logg'], selectAllData($conn,'ratesperkilometre','rate','Id',1)); 
                    }

                    updateFunction($conn,'employee','status','Booked','empID',$_SESSION['empId']);
                    updateFunction($conn,'employee','appointmentID',selectAllData($conn,'appointment','appointmentID','custID',selectAllData($conn,'customers','custID','custEmail',$_SESSION['email'])),'empID',$_SESSION['empId']);
                    updateFunction($conn,'employee','paymentID',selectAllData($conn,'payment','paymentID','custID',selectAllData($conn,'customers','custID','custEmail',$_SESSION['email'])),'empID',$_SESSION['empId']);

                    header("Location:./user.php?oder=complete");
                }
            }
            if(isset($_GET['oder'])){
                if($_GET['oder'] == 'complete'){
                    if(updateFunction($conn,'customers','AppointmentID',selectAllData($conn,'appointment','appointmentID','custID',selectAllData($conn,'customers','custID','custEmail',$_SESSION['email'])),'custID',selectAllData($conn,'customers','custID','custEmail',$_SESSION['email'])) == true){
                        $userSuccessPointmentAlert = "";
                    }
                    if(updateFunction($conn,'customers','PaymentID',selectAllData($conn,'payment','paymentID','custID',selectAllData($conn,'customers','custID','custEmail',$_SESSION['email'])),'custID',selectAllData($conn,'customers','custID','custEmail',$_SESSION['email'])) == true){
                        $userSuccessPointmentAlert = "";
                    }
                }
            }
        }
    }

    if(isset($_SESSION['ServiceLocation'])){

        if($_SESSION['ServiceLocation'] == 'Salon'){
            //Salon processing
            //Check if transaction is complete
            if(isset($_GET['transection'])){
                if($_GET['transection'] == 'confirmation'){

                    if(selectAllData($conn,'location','custID','custID',selectAllData($conn,'customers','custID','custEmail',$_SESSION['email'])) == true){
                        updateFunction($conn,'location','Latitude',$_SESSION['lattt'],'custID',selectAllData($conn,'customers','custID','custEmail',$_SESSION['email']));
                        updateFunction($conn,'location','Longitude',$_SESSION['Logg'],'custID',selectAllData($conn,'customers','custID','custEmail',$_SESSION['email']));
                    }else{
                        insertLocation($conn,selectAllData($conn,'customers','custID','custEmail',$_SESSION['email']),$_SESSION['lattt'],$_SESSION['Logg'], selectAllData($conn,'ratesperkilometre','rate','Id','1'));
                    }

                    insertAppointemt($conn,$_SESSION['Date'],$_SESSION['Time'],selectAllData($conn,'customers','custID','custEmail',$_SESSION['email']),$_SESSION['empId'],$_SESSION['ServiceLocation'], $_SESSION['stleId']);
                    insertHairstyle($conn,$_SESSION['style'],selectAllData($conn,'customers','custID','custEmail',$_SESSION['email']));
                    insertPayment($conn,selectAllData($conn,'customers','custID','custEmail',$_SESSION['email']),$_SESSION['empId'],$_SESSION['Price'],selectAllData($conn,'hairstyle','hairStyleID','hairStyleName',$_SESSION['style']));
                    updateFunction($conn,'employee','status','Booked','empID',$_SESSION['empId']);
                    updateFunction($conn,'employee','appointmentID',selectAllData($conn,'appointment','appointmentID','custID',selectAllData($conn,'customers','custID','custEmail',$_SESSION['email'])),'empID',$_SESSION['empId']);
                    updateFunction($conn,'employee','paymentID',selectAllData($conn,'payment','paymentID','custID',selectAllData($conn,'customers','custID','custEmail',$_SESSION['email'])),'empID',$_SESSION['empId']);

                   
                    header("Location:./user.php?oder=complete");
                }
            }
            if(isset($_GET['oder'])){
                if($_GET['oder'] == 'complete'){
                    if(updateFunction($conn,'customers','AppointmentID',selectAllData($conn,'appointment','appointmentID','custID',selectAllData($conn,'customers','custID','custEmail',$_SESSION['email'])),'custID',selectAllData($conn,'customers','custID','custEmail',$_SESSION['email'])) == true){
                        $userSuccessPointmentAlert = "";
                    }
                    if(updateFunction($conn,'customers','PaymentID',selectAllData($conn,'payment','paymentID','custID',selectAllData($conn,'customers','custID','custEmail',$_SESSION['email'])),'custID',selectAllData($conn,'customers','custID','custEmail',$_SESSION['email'])) == true){
                        $userSuccessPointmentAlert = "";
                    }
                }
            }
            
        }else{
            
        }
    }

    //Check anyactive appointments
    if(selectAllData($conn,'customers','AppointmentID','custEmail',$_SESSION['email']) != 0){
        $globalBookingControl = "activeBooking";
        $globalAccessBooking = "accessBookings";
        //
    }else{
        $globalBookingControl = "makeABooking";
        $globalAccessBooking = "noBookingActive";
        //
    }
    //Cancell oder
    if(isset($_POST['btnCancelOder'])){
        daleteFunction($conn,'appointment','custID',selectAllData($conn,'customers','custID','custEmail',$_SESSION['email']));
        daleteFunction($conn,'payment','custID',selectAllData($conn,'customers','custID','custEmail',$_SESSION['email']));

        if(updateFunction($conn,'customers','AppointmentID',0,'custEmail',$_SESSION['email']) == true){
            header('Location:user.php?cancel=success');
        }

    }
    if(isset($_GET['cancel'])){
        if($_GET['cancel'] == 'success'){
            if(isset($_SESSION['empId'])){
                updateFunction($conn,'employee','status','Available','empID',$_SESSION['empId']);
                $alertCancellSuccess = "";
            }
        }
    }

}else{
    $sessionOff = "";
    $mainUserPage = "none";
}
//Registering users
if(isset($_POST['BtnRegisterUser'])){

    //Check if a user exist testting the ssystem of this nature 
    if(selectAllData($conn,'customers','custEmail','custEmail',$_POST['email']) == $_POST['email']){
        //___________________________User exit 
        $userExist = "";

    }else{
        //___________________________Insert User
       if(insertUsers($conn, $_POST['name'],$_POST['surname'], $_POST['id_No'], $_POST['cell'], $_POST['email'], $_POST['password']) == true){
           //Success
           $registerSccess = "";
       }
       else{
           //Fail
            $registerFail = "";
       }
    }
}
//__________________________________________________________________
//Logout btn
if(isset($_GET['logout'])){
   
    session_destroy();
    header('Location:./index.php');
    exit();
}if(isset($_GET['logoutAdmin'])){
    session_destroy();
    header('Location:../index.php');
}
//_____________________________________________________________________________________________________________________________________________
//Login admin section
//Check if the email exist first
if(isset($_POST['btnLoginAdmin'])){

    if(selectAllData($conn,'admin','email','email',$_POST['email']) == $_POST['email']){

        //Check if the password exist
        if(selectAllData($conn,'admin','password','password',$_POST['password']) == $_POST['password']){

            //set all session to be active
            $_SESSION['emailAdmin'] = $_POST['email'];
    
            //Direct admin to the dashbord
            header('Location:./admin/dashboard.php');
        }
        else{
            //Direct to the login page with password error 
            header('Location:index.php?password=error');
            //exit();
        }
    
    }else{
        if(selectAllData($conn,'employee','empEmail','empEmail',$_POST['email']) == $_POST['email']){

            //Check if the password exist
            if(selectAllData($conn,'employee','empPassword','empPassword',$_POST['password']) == $_POST['password']){
    
                //set all session to be active
                $_SESSION['emailEmp'] = $_POST['email'];
        
                //Direct admin to the dashbord
                header('Location:./admin/dashboard.php');
            }
            else{
                //Direct to the login page with password error 
                //header('Location:index.php?password=error');
                echo "Error password";
                //exit();
            }
        
        }else{
            //header('Location:index.php?email=error');
            echo "error email";
            //exit();
    
        }
    }
}    


if(isset($_SESSION['emailAdmin']) || isset($_SESSION['emailEmp'])){
    $mainSectionAdmin = "";
    //Update admin information
    if(isset($_POST['btnUpdateAdmin'])){

        if(updateFunction($conn,'admin','password',$_POST['password'],'email',$_SESSION['emailAdmin']) == true && 
            updateFunction($conn,'admin','email',$_POST['email'],'email',$_SESSION['emailAdmin']) == true){
                $_SESSION['emailAdmin'] = $_POST['email'];
                header('Location:./dashboard.php?admin=updated');
        }
    }
    //Add employee location
    if(isset($_GET['lat']) && isset($_GET['Lon'])){
            
        if(selectAllData($conn,'location','custID','custID',selectAllData($conn,'employee','empID','empEmail',$_SESSION['emailEmp']))){
            //Location update
            updateFunction($conn,'location','Latitude',$_GET['lat'],'custID',selectAllData($conn,'employee','empID','empEmail',$_SESSION['emailEmp']));
            updateFunction($conn,'location','Longitude',$_GET['Lon'],'custID',selectAllData($conn,'employee','empID','empEmail',$_SESSION['emailEmp']));

        }else{
            if(insertLocation($conn,selectAllData($conn,'employee','empID','empEmail',$_SESSION['emailEmp']),$_GET['lat'],$_GET['Lon'], selectAllData($conn,'ratesperkilometre','rate','Id',1)) == true){
                header('Location:./dashboard.php?location=success');
            }
        }
    }
    /////////////////////////////////////////
    //Complete appointment
    if(isset($_POST['btnCompleteOder'])){

         updateFunction($conn,'employee','status','Available','empEmail',$_SESSION['emailAdmin']);
         daleteFunction($conn,'appointment','custID',$_GET['recordId']);
         daleteFunction($conn,'payment','custID',$_GET['recordId']);

         if(updateFunction($conn,'customers','AppointmentID',0,'custID',$_GET['recordId']) == true){
            header('Location:./dashboard.php?complete=success');
         }

     }
     if(isset($_GET['complete'])){
         $alertOderComplete = "";
     }


    if(isset($_SESSION['emailEmp'])){
        $hideProfileOnAdmin = "";
        if(selectAllData($conn,'location','custID','custID',selectAllData($conn,'employee','empID','empEmail',$_SESSION['emailEmp'])) == selectAllData($conn,'employee','empID','empEmail',$_SESSION['emailEmp'])){
            //Ask to set the loction
            $locationEmpSet = "none";
            $hideOders = "";
        }else{
            //Ask to set the location
            $locationEmpSet = "";
            $hideOders = "none";
        }
        
    }else{
        $hideProfileOnAdmin = "none";
        $adminL = "none";
    }

    //Update employee information
    if(isset($_POST['btnUpdatEmp'])){
        updateFunction($conn,'employee','empName',$_POST['name'],'empEmail',$_SESSION['emailEmp']);
        updateFunction($conn,'employee','empSurname',$_POST['surname'],'empEmail',$_SESSION['emailEmp']);
        if(updateFunction($conn,'employee','empEmail',$_POST['email'],'empEmail',$_SESSION['emailEmp']) == true){
            $_SESSION['emailEmp'] = $_POST['email'];
        }
        updateFunction($conn,'employee','empPassword',$_POST['password'],'empEmail',$_SESSION['emailEmp']);
        $successEmpProfile = "";
    }
    //Admin delete user account
        if(isset($_POST['btnDeleteUser'])){
             if(daleteFunction($conn,'customers','custID',$_GET['userId']) == true){
                
                daleteFunction($conn,'appointment','custID',$_GET['userId']);
                daleteFunction($conn,'hairstyle','custID',$_GET['userId']);
                daleteFunction($conn,'location','custID',$_GET['userId']);
                daleteFunction($conn,'payment','custID',$_GET['userId']);

                header('Location:./dashboard.php?UserD=success');
             }
        }
        if(isset($_GET['UserD'])){
            //Show alert
            $deleteUserAdmin = "";
        }

    if(isset($_SESSION['emailAdmin'])){
        ///////////////////////////////////////////////////////////////
        //Add employee
        if(isset($_POST['btnAddEmp'])){

            if(selectAllData($conn,'employee','empEmail','empEmail',$_POST['email']) == $_POST['email']){
                $adminAddEmpExist = "";
            }else{
                if(insertEmployee($conn,$_POST['email'],$_POST['password'],$_POST['name'],$_POST['surname']) == true){
                    header('Location:./dashboard.php?addEmp=success');
                }
            }
 
        }
        if(isset($_GET['addEmp'])){
            $adminAddEmp = "";
        }

        if(isset($_GET['recordId'])){$_SESSION['empRecId'] = $_GET['recordId'];}
        //Update employee
        if(isset($_POST['btnUpdateEmp'])){

         
            updateFunction($conn,'employee','empPassword',$_POST['password'],'empID',$_SESSION['empRecId']);
            updateFunction($conn,'employee','empName',$_POST['name'],'empID',$_SESSION['empRecId']);
            updateFunction($conn,'employee','empSurname',$_POST['surname'],'empID',$_SESSION['empRecId']);

            if(updateFunction($conn,'employee','empEmail',$_POST['email'],'empID',$_SESSION['empRecId']) == true) {
                
                header('Location:./employee-record.php?empAdminUpdate=success&recordId='.$_SESSION['empRecId']);
            }
        }
        if(isset($_GET['empAdminUpdate'])){
            $adminUpdateEmp = "";
        }
        //Delete employee
        if(isset($_GET['recordId'])){$_SESSION['empRecId'] = $_GET['recordId'];}
        if(isset($_GET['deleteAdminRecord'])){
            if(daleteFunction($conn,'employee','empID',$_SESSION['empRecId']) == true){
                header('Location:./dashboard.php?deleteEmpRec=success');
            }
        }
        if(isset($_GET['deleteEmpRec'])){
            $alertAdminDeleteSucces = "";
        }

        $showAdmin = "";

    }else{
        $showAdmin = "none";
       
    }
}else{
    $sessionOver = "";
}
if(isset($_GET['admin'])){
    $adminUpdateSuccess = "";
}