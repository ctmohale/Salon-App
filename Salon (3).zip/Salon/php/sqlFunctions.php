<?php 
    @session_start();
    //----------------------------------------------------------------------------------------------
    //All the sql functions (Global select function)
    function selectAllData($conn,$tableName,$dataToSelect,$dataSelectedIdOnTable,$dataSelectId){

        $sqlSe = "SELECT $dataToSelect FROM $tableName WHERE $dataSelectedIdOnTable = '$dataSelectId'";
        $resultSelected = $conn->query($sqlSe);

        if ($resultSelected->num_rows > 0) {
            // output data of each row
            while($row = $resultSelected->fetch_assoc()) {
                return $row[$dataToSelect];
            }
        } else {
            return false;
        }
    }
    //----------------------------------------------------------------------------------------------
    //Insert users any type of data in the tables
    function insertUsers($conn, $Name, $Surname, $Id_no, $Cell_No, $Email, $Password){
        //Variable
        $Gender = "";
        //Get Gender from an id number 
        if(intval(substr($Id_no,6,1)) < 5){ $Gender = "Female";} else{ $Gender = "Male"; }

        $sql = "INSERT INTO customers (custName, custSurname, custID_NO, custContact, custEmail, custPassword, Gender,AppointmentID,PaymentID,LocationID)
        VALUES ('$Name', '$Surname', '$Id_no', '$Cell_No', '$Email','$Password', '$Gender','0','0','0')";
        
        if ($conn->query($sql) === TRUE) { 
            return true;
        } else {
          echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    //----------------------------------------------------------------------------------------------
    //Update any type of data in the tables
    function insert($conn, $QuestionId, $Answer, $Correction, $Email){

        $sql = "INSERT INTO useranswer (Qid, Ans, Correction, Username)
        VALUES ('$QuestionId', '$Answer', '$Correction', '$Email')";
        
        if ($conn->query($sql) === TRUE) { 
            return true;
        } else {
            return "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    function insertAppointemt($conn, $Date, $Time, $custID, $empId,$serviceLocation, $styleID){

        $sql = "INSERT INTO appointment (appointDate, appointTime, custID, empID, status, service_location, hairStyleID)
        VALUES ('$Date', '$Time', '$custID', '$empId','Pending','$serviceLocation', '$styleID')";
        
        if ($conn->query($sql) === TRUE) { 
            return true;
        } else {
            return "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    function insertHairstyle($conn, $Style, $CustID){

        $sql = "INSERT INTO hairstyle (hairStyleName, custID)
        VALUES ('$Style', '$CustID')";
        
        if ($conn->query($sql) === TRUE) { 
            return true;
        } else {
            return "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    function insertPayment($conn, $custID,$empId, $amount, $styleId){

        $sql = "INSERT INTO payment (custID, empID,amoutRand, hairStyleID)
        VALUES ('$custID', '$empId', '$amount', '$styleId')";
        
        if ($conn->query($sql) === TRUE) { 
            return true;
        } else {
            return "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    //Insert location inside the databse
    function insertLocation($conn, $User_ID, $Lat, $Log, $rateID){

        $sql = "INSERT INTO location (custID, Latitude, Longitude, rate_Id)
        VALUES ('$User_ID', '$Lat', '$Log', '$rateID')";
        
        if ($conn->query($sql) === TRUE) { 
            return true;
        } else {
            return "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    //Insert location inside the databse
    function insertEmployee($conn, $email, $Password, $name, $surname){

        $sql = "INSERT INTO employee (empEmail, empPassword, empName, empSurname, appointmentID, paymentID, status)
        VALUES ('$email', '$Password', '$name', '$surname', 0, 0,'Available')";
        
        if ($conn->query($sql) === TRUE) { 
            return true;
        } else {
            return "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    //----------------------------------------------------------------------------------------------
    //Update any type of data in the tables
    function updateFunction($conn, $tableName, $selectedFiled, $updateData, $selectedFiledForId, $filedId){
        $sql = "UPDATE $tableName SET $selectedFiled = '$updateData' WHERE $selectedFiledForId = '$filedId' ";

        if ($conn->query($sql) === TRUE) {
            return true;
        } else {
            return false;
        }
    }
    //----------------------------------------------------------------------------------------------
    //Update any type of data in the tables
    function distanceA($lat1, $lon1, $lat2, $lon2) { 
        $pi80 = M_PI / 180; 
        $lat1 *= $pi80; 
        $lon1 *= $pi80; 
        $lat2 *= $pi80; 
        $lon2 *= $pi80; 
        $r = 6372.797; // mean radius of Earth in km 
        $dlat = $lat2 - $lat1; 
        $dlon = $lon2 - $lon1; 
        $a = sin($dlat / 2) * sin($dlat / 2) + cos($lat1) * cos($lat2) * sin($dlon / 2) * sin($dlon / 2); 
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a)); 
        $km = $r * $c; 
        //echo ' '.$km; 
        return $km; 
    }
    //Second function
    function distance($lat1, $lon1, $lat2, $lon2, $unit) {
        if (($lat1 == $lat2) && ($lon1 == $lon2)) {
          return 0;
        }
        else {
          $theta = $lon1 - $lon2;
          $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
          $dist = acos($dist);
          $dist = rad2deg($dist);
          $miles = $dist * 60 * 1.1515;
          $unit = strtoupper($unit);
      
          if ($unit == "K") {
            return ($miles * 1.609344);
          } else if ($unit == "N") {
            return ($miles * 0.8684);
          } else {
            return $miles;
          }
        }
    }
    //----------------------------------------------------------------------------------------------
    //This function counts and return the total count
    //This function counts and return the total count
    function mainCountStat($conn,$tableName, $dataSelected,$dataSelected_Clues, $dataSelectedId, $dataSelectedId_Clues){

        //Set the counter
        $countData = 0;
        $sql = "";
        if($dataSelected_Clues != ''){
            $sql = "SELECT * FROM $tableName WHERE $dataSelected = '$dataSelectedId' AND $dataSelected_Clues = '$dataSelectedId_Clues'";
        }
        else if($dataSelected_Clues == '' && $dataSelected == ''){
            $sql = "SELECT * FROM $tableName ";
        }else{
            $sql = "SELECT * FROM $tableName WHERE $dataSelected = '$dataSelectedId'";
        }
        
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
          // output data of each row
          while($row = $result->fetch_assoc()) {
            $countData++;
          }
        } else {
            $countData = 0;
        }
        //Return the counter value
        return $countData;
    }
    //----------------------------------------------------------------------------------------------
    //Delete function
    function daleteFunction($conn,$tableName,$selectedRecord,$recordId){
        $sql = "DELETE FROM $tableName WHERE $selectedRecord = $recordId";

        if ($conn->query($sql) === TRUE) {
            return true;
        } else {
            return false;
        }
    }
    //Select Ansewrs Oppenness function
    if(isset($_SESSION['email'])){
        //----------------------------------Manual Selection of Data-------------------------------------------------
        //Select questions function
        $sqlSelectAllQuestions = "SELECT * FROM question";
        $resultQuestions = $conn->query($sqlSelectAllQuestions);

        $sqlSelectAnswersPersonality = "SELECT * FROM useranswer  WHERE Username = '$_SESSION[email]'";
        $resultAnswersPersonality = $conn->query($sqlSelectAnswersPersonality);
    }

    //Select all users 
    $sqlSelectAllcustomers = "SELECT * FROM customers";
    $resultSelectAllcustomers = $conn->query($sqlSelectAllcustomers);

    //Select all oders 
    $sqlSelectAllOders = "SELECT * FROM appointment";
    $resultSelectAllOders = $conn->query($sqlSelectAllOders);

    //Select all oders 
    $sqlSelectAllemployee = "SELECT * FROM employee";
    $resultSelectAllemployee = $conn->query($sqlSelectAllemployee);

    $sqlAllFromLocation = "SELECT * FROM location";
    $resultSelectedFromLocation = $conn->query($sqlAllFromLocation);

    if ($resultSelectedFromLocation->num_rows > 0) {
        
        // output data of each row
        while($row = $resultSelectedFromLocation->fetch_assoc()) {
            
            //Select all oders 
            $sqlSelectAvailableStylist = "SELECT * FROM employee WHERE status = 'Available'";
            $resultSelectAvailableStylist = $conn->query($sqlSelectAvailableStylist);  
        }
    }