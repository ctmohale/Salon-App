<?php
include './connect.php';
include './control.php';
require('./fpdf/fpdf.php');

class PDF extends FPDF
{
    function hader()
    {
        $this->SetFont('Arial', 'B', 14);
        $this->Cell(276, 5, 'Salon ( Control Management System ) ', 0, 0, 'C');
        $this->Ln();
        $this->SetFont('Times', '', 12);
        $this->Cell(276, 10, 'Employee records', 0, 0, 'C');
        $this->Ln(20);
        $this->Cell(276, 10, '--------------------------------------------------------------------', 0, 0, 'C');
        $this->Ln(20);
    }
    function footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial', '', 8);
        //$this->Cell(0, 10, 'Page'.this->PageNo().'/{nb}',0,0, 'C');
    }
    function headerTable()
    {
        $this->SetFont('Times', 'B', 12);
        $this->Cell(10, 10, 'Id', 1, 0, 'C');
        $this->Cell(70, 10, 'Name', 1, 0, 'C');
        $this->Cell(70, 10, 'Surname', 1, 0, 'C');
        $this->Cell(70, 10, 'Email', 1, 0, 'C');
        $this->Cell(60, 10, 'Status', 1, 0, 'C');
        $this->Ln();
    }
    function dataFromDb($conn)
    {
        $this->SetFont('Times', '', 12);
        $sql = "SELECT*From employee";
        $result = $conn->query($sql);

        while ($row = $result->fetch_assoc()) {
            $this->SetFont('Times', 'B', 12);
            $this->Cell(10, 10, $row['empID'], 1, 0, 'L');
            $this->Cell(70, 10, $row['empName'], 1, 0, 'L');
            $this->Cell(70, 10, $row['empSurname'], 1, 0, 'L');
            $this->Cell(70, 10, $row['empEmail'], 1, 0, 'L');
            $this->Cell(60, 10, $row['status'], 1, 0, 'L');
            $this->Ln();
        }
    }
}
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage('L', 'A4', 0);
$pdf->hader();
$pdf->headerTable();
$pdf->dataFromDb($conn);
$pdf->Output();
